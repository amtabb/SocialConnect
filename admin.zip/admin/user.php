<?php
//Garvita created the html
//Abdul added logic
//Roshan provided sql
include 'db.php';
include 'head.php';

if(isset($_POST['first_name'])){


extract($_POST);
$date = date("Y-m-d"); 
	
$username = strtolower($first_name . "_" . $last_name .  mt_rand(0,9999));




$sql = "SELECT * from users where email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
	$first_name = $row['first_name'];
	$last_name = $row['last_name'];
	$username = $row['username'];
	?>
	<center>
	  <h2 class="text-danger mt-5"><?=$email ;?> is already exists in database.</h2>
	  <a class="btn btn-success btn-block btn-lg" target="_blank" href="loginAs.php?user=<?=$username;?>">Login as <?=$first_name;?> <?=$last_name;?> </a>
	 </center>
<?php 
	exit;
  }
}



$password = md5($password);


$sql = "INSERT INTO users (first_name, last_name, email,username,signup_date,password,profile_pic,num_posts,num_likes,user_closed,friend_array,disabled)
VALUES ('$first_name', '$last_name', '$email','$username','$date','$password',1,'0','0','0',',','0')";

//$sql = "INSERT INTO users (first_name, last_name, email, username, signup_date, password, profile_pic, num_posts, num_likes, user_closed, friend_array, disabled) VALUES ('$first_name', '$last_name', '$email', '$username', '$date', '$password', '1', '0', '0', 'no', ',','0')");

if ($conn->query($sql) === TRUE) {
	?>
		<center>
	  <h2 class="text-success mt-5 display-3">User created.</h2>
	  <a class="btn btn-success btn-block btn-lg" target="_blank" href="loginAs.php?user=<?=$username;?>">Login as <?=$first_name;?> <?=$last_name;?> </a>
	 </center>
	<?php
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}






exit;
}


?>
<h2 class=" text-success mt-5">Create New User</h2>
 <div class="container">
  <div class="row">
   <div class="col-md-6 col-sm-6 col-xs-12">
    <form method="post" method="post">
     <div class="form-group ">
      <label class="control-label " for="first_name">
       First Name
      </label>
      <input class="form-control" id="first_name" name="first_name" type="text" required="required" />
     </div>
     <div class="form-group ">
      <label class="control-label " for="last_name">
       Last Name
      </label>
      <input class="form-control" id="last_name" name="last_name" type="text" required="required" />
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="email">
       Email
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="email" name="email" type="text" required="required" />
     </div>
     <div class="form-group ">
      <label class="control-label " for="password">
       Password
      </label>
      <input class="form-control" id="password" name="password" type="text" required="required" />
     </div>
     <div class="form-group">
      <div>
       <button class="btn btn-primary mt-2" name="submit" type="submit">
        Submit
       </button>
      </div>
     </div>
    </form>
   </div>
  </div>
 </div>
